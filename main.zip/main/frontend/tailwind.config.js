/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "../templates/**/*.html",
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
