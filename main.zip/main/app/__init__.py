"""
Paquete principal de la aplicación Logix.
"""
