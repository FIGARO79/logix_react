"""
Módulo de utilidades.
"""
