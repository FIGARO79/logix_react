"""
Módulo de modelos.
"""
