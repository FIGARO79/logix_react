"""
Módulo de configuración core.
"""
